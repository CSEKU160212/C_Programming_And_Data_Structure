#include<stdio.h>
int main()
{
    int i,j,k,l,n;
    printf("enter line to be printed:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        for(j=0;j<n-i;j++)
        {
              printf(" ");
        }
        for(k=i;k>0;k--)
        {
            printf("%d",k);
        }
        for(l=2;l<i;l++)
        {
            printf("%d",l);
        }
        printf("\n");
    }
}
