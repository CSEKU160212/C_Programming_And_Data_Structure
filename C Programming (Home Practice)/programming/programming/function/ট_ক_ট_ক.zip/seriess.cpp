#include<stdio.h>
int main()
{
    long long int a,i,sum=0;
    scanf("%lld",&a);
    for(i=2;i<=a;i=i+2)
    {
        sum=sum+i;
    }
    printf("summation is %lld.\n",sum);
}
