#include<stdio.h>
int main()
{
    int i,t;
    float a,b,c,c_rate,r_rate,crate,rr,rrate;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        scanf("%f%f%f",&a,&b,&c);
        c_rate=(b/(300-c));
        crate=c_rate*6;
        r_rate=((a-b)+1);
        rr=r_rate/c;
        rrate=rr*6;
        printf("%.2f %.2f\n",crate,rrate);
    }


}
