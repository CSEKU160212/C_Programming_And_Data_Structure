#include<stdio.h>
int main()

{
    int a,sum;
    while(scanf("%d",&a)==1)
    {
        if(a==0)
        {
           break;
        }
           sum=a/2;
    printf("%d\n",sum);
    }
}

