#include<stdio.h>
int main()
{
    int i,t,stand,borrow,sm,caseno;
    char man[8];
    scanf("%d",&t);
    {
        for(caseno=1;caseno<=t;caseno++)
        {
            freopen("input.txt","r",stdin);
            freopen("output.txt","w",stdout);
            scanf("%d %s",&sm,&man);
            stand=0;
            borrow=0;
            for(i=0;i<=sm+1;i++)
            {
                if(stand>=i)
                {
                    stand=stand+man[i]-48;
                }
                else
                {
                    borrow+=(i-stand);
                    stand+=(i-stand);
                    stand+=(man[i]-48);
                }
            }
            printf("Case # %d: %d",i,borrow);



        }
    }

}
