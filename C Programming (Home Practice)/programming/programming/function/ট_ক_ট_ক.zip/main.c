#include<avr/io.h>
#include<util/delay.h>
#int main(void)

{ 
         DRDB |=(1<DDB0)|(1<DDB1)|(1<DDB2)|(1<DDB3);
		 while(1)
		 {
		 PORTB=0b0000111;
		 _delay_ms(50);
		 PORTB=0b00000000;
		 _delay_ms(50);
		 }
		 return 0;
}