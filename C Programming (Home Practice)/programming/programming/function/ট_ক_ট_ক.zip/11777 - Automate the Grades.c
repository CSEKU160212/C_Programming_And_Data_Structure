#include<stdio.h>
int main()

{
    int t1,t2,t3,at,c1,c2,c3,t,i,total,aver,A,B,C;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        total=0;
        scanf("%d%d%d%d%d%d%d",&t1,&t2,&t3,&at,&c1,&c2,&c3,&t,&i);
        if(c1<=c2&&c1<=c3)
        {
            aver=(c2+c3)/2;
        }
        else if(c2<=c1&&c2<=c3)
        {
            aver=(c1+c3)/2;
        }
        else if(c3<=c2&&c3<=c1)
        {
            aver=(c2+c1)/2;
        }
              total=t1+t2+t3+at+aver;

        if(total>=90)
        {
            printf("Case %d: A\n",i);
        }
        else if(total>=80&&total<90)
        {
            printf("Case %d: B\n",i);
        }
        else if(total>=70&&total<80)
        {
            printf("Case %d: C\n",i);
        }
        else if(total>=60&&total<70)
        {
            printf("Case %d: D\n",i);
        }
        else if(total<60)
        {
            printf("Case %d: F\n",i);
        }
    }

}
