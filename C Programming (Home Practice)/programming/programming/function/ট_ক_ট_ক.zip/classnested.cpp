#include<stdio.h>
int main()
{
    int i,j,t;
    scanf("%d",&t);
    for(i=0; i<t; i++)
    {
        for(j=1; j<(t)-i; j++)
        {
            printf(" ");
        }

        for(int k=1; k<=(i*2)+1; k++)
        {
            printf("%d",k);
        }
             printf("\n");
    }
}
