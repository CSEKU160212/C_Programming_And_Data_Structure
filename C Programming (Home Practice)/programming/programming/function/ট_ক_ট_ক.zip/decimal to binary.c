#include<stdio.h>
int main()

{
    int i,a,rem,s,k=0;
    scanf("%d",&a);
    for(i=1;;i++)
    {
        rem=a%2;
        a=a/2;
        k=(k*10)+rem;
        if(a==0)
        {
            break;
        }
    }

    s=k;

    {
            for(i=0;;i++)
            {
                rem=a%10;
                a=a/10;
                s=(s*10)+rem;
                if(a==0)
                {
                    break;
                }

            }
            printf("%d\n",s);
}
}


