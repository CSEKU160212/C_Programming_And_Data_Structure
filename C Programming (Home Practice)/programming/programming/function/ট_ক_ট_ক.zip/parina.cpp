#include<stdio.h>
int main()
{

    int i,a,rem,n,res;
    scanf("%d",&a);
    res=0;
    n=0;
    for(i=1; ;i++)
    {
        rem=a%2;
        a=a/2;
        res=(res*10)+rem;
        if(a==0)
        {
            break;
        }
    }
        n=res;
    {
        for(int i=0;;i++)
        {
            rem=a%10;
            a=a/10;
            n=(n*10)+rem;
            if(a==0)
            {
                break;
            }
        }
        printf("binary  is %d\n",n);
    }


}
