#include<stdio.h>
int main()
{
    int a,b;
    a=-20;
    b=7;
    int c=a%b;
    printf("%d",c);
}
