#include<stdio.h>
int main()
{
    int i,j,k,t,sum=0,a,b;
    scanf("%d",&t);

    for(i=0;i<=a;i++)
    {
        if(a==1)
        {
            printf("1");
        }

            sum=sum+a;

           printf("%d",sum);
           break;
    }



}
