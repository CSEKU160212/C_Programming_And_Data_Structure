#include<stdio.h>
int main()
{
    int t;
    printf("enter line to print:");
    scanf("%d",&t);
    for(int i=t; i>=0; i--)
    {
        for(int j=t-i; j>0; j--)
        {
            printf(" ");
        }
        for(int k=(2*i)+1; k>0; k--)
        {
            printf("*");
        }
        for(int l=t; l>=0; l--)
        {
            for(int m=t-i; m>0; m--)
            {
                printf(" ");
            }
            for(int n=(2*i)+1; n>0; n--)
            {
                printf("*");
            }
            printf("\n");
         }

    }

}

