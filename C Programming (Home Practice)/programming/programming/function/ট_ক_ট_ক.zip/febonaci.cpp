#include<stdio.h>

int main()
{
    int n,a,b,c;
    a=1;
    b=1;
    scanf("%d",&n);
    for(int i=1;i<n;i++)
    {
        if(i==1)printf("1 ");
        printf("%d ",b);
        c=a+b;
        a=b;
        b=c;

    }
}
