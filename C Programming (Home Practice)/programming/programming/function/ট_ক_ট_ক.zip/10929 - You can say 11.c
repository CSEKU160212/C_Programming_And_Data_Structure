#include<stdio.h>
int main()
{
    long long int N;
    while(scanf("%lld",&N)==1)
    {

       if(N==0)
        {
            break;
        }
        else if(N%11==0)
        {
            printf("%lld is a multiple of 11.\n",N);
        }
        else
        {
            printf("%lld is not a multiple of 11.\n",N);
        }

    }
    return 0;

}
