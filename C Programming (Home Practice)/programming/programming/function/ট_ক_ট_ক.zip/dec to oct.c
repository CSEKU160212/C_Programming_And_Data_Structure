#include<stdio.h>
int main()
{
    char ch;
    int n=99;
    printf("%c",n);
}
