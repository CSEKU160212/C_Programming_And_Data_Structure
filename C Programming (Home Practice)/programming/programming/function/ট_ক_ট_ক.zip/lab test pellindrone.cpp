                                       //150232//

#include<stdio.h>
int main()

{
  int i,rem,s,n,res=0;
  scanf("%d",&n);
  s=n;
  for(i=0; ;i++)
  {
      rem=n%10;
      n=n/10;

      res=(res*10)+rem;
      if(n==0)
      {
          break;
      }
  }
      if(s==res)printf("palindrome.\n");
      else  printf("not palindrome.\n");

}




