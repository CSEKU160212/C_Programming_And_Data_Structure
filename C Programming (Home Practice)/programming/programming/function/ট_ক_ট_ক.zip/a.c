#include<stdio.h>
int main()
{
    int a,b,c,i,t,k;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        scanf("%d%d%d",&a,&b,&c);
        if(a<b&&b<c)
        {
            k=(b+c)/2;
        }

    }
    printf("%d\n",k);
}
