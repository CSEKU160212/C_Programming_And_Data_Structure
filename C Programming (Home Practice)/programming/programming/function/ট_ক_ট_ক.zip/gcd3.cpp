#include<stdio.h>
int main()
{
    int i,a,b,rem;
    scanf("%d%d",&a,&b);
    for(i=1;;i++)
    {
        rem=a%b;
        a=a/b;
        a=b;
        b=rem;

    }
    printf("gcd is %d\n",b);
}
