#include<stdio.h>
#include<iostream>
using namespace std;
int main()
{
    int i,a;
    char s[a];
    scanf("%d %s",&i,&a);

}
