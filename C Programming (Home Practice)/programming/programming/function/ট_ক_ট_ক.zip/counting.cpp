#include<stdio.h>
int main()
{
    int i,j,t,count=0;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        for(j=1;j<=i+1;j++)
        {
            count=1;
        }
        printf("%d\n",count);
    }

}
