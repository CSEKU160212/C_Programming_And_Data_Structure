#include<stdio.h>
int main()
{
    int a,t,i,flag=0,rem=0;
    while(scanf("%d",&a)==1)
    {
        if(a==0)
        {
            break;
        }
        for(i=2;i<a;i++)
        {
            rem=a%i;
            if(rem==0)
            {

                printf("%d\n",i);
                break;
            }


        }
        if(rem!=0)
        {

            printf("prime.\n");

        }
    }

}
