#include<stdio.h>
int main()
{
    int i,n,s,rem,res=0,c;
    scanf("%d",&n);
    for(i=1; ; i++)
    {
        rem=n%2;
        n=n/2;
        res=(res*10)+rem;
        c=i;
        if(n==0)
        {
            break;
        }
    }
        s=0;
    for(i=1; i<=c; i++)
    {

        rem=res%10;
        res=res/10;
        s=(s*10)+rem;

    }
    printf("%d\n",s);
}
