#include<stdio.h>
int main()
{
    int t,smax,n,j,i,stand;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {

       int borrow=0;
       stand=0;
        scanf("%d",&smax);
        for(j=1;j<=smax+1;j++)
        {
            scanf("%d",&n);

            if(n>stand)
            {

                stand+=n;
            }
            else
            {
                borrow+=(i-stand);
                stand+=n;
                n=stand;
            }

        }
        printf("Case %d : %d\n",i,borrow);
    }
}
