#include<stdio.h>
int main()
{
    int i,t,a,b,c;
    scanf("%d",&t);
    while(t<20)
    {
    for(i=1;i<=t;i++)
    {
        while(scanf("%d%d%d",&a,&b,&c)==3)

        {

        if((a+b)<=c||(b+c)<=a||(c+a)<=b)
        {
            printf("Case %d: Invalid\n",i);
            break;
        }
        else if(a==b&&b==c)
        {
            printf("Case %d: Equilateral\n",i);
            break;
        }
        else if(a==b||b==c||c==a)
        {
            printf("Case %d: Isosceles\n",i);
            break;
        }
        else
        {
            printf("Case %d: Scalene\n",i);
            break;

        }
    }
        }
    }

}



