#include<stdio.h>
int main()
{
    int i,j,n,sum=0;
    scanf("%d",&n);
    for(i=0;i<=n;i=i+1)
    {
        for(j=1;j<=(2*i)+i;j++)

        {

            printf("%d",sum);
        }
    }
}

