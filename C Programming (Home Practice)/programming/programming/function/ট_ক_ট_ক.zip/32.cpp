#include<stdio.h>
int main()
{
    int i,a
}
