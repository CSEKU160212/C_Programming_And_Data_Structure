#include<stdio.h>
#include<math.h>
int main()
{
    int a,i,t,b;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        scanf("%d",&a);
        b=sqrt(a);
        if(a==(b*b))
        {
            printf("YES\n");
        }
        else
        {
            printf("NO\n");
        }

    }
}
