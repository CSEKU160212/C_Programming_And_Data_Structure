#include<stdio.h>
int main()
{
    int i,a,b,c,d,e,t,f=0;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);
        if(a>b&&a>c&&a>d&&a>e)
        {

        }
        else if(b>a&&b>c&&b>d&&b>e)
        {
            f=b;
        }
        else if(c>a&&c>b&&c>d&&c>e)
        {
            f=c;
        }
        else if(d>a&&d>b&&d>c&&d>e)
        {
          f=d;
        }
        else if(e<a&&e<b&&e<c&&e<d)
        {
            f=e;
        }
        printf("%d\n",a);
    }

}
