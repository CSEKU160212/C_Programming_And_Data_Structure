#include<stdio.h>
int main()
{
    int i,j,k,l,t;
    printf("enter line to be printed.\n");
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        for(j=0;j<t-i;j++)
        {
            printf("*");
        }
        for(k=0;k<(2*t-2*j);k++)
        {
            printf(" ");
        }
        for(j=0;j<t-i;j++)
        {
            printf("*");
        }
        printf("\n");
    }


}
