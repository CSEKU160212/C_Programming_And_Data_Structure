#include<stdio.h>
int main()
{
    int t,k,i,j,n;
    printf("enter line to be printed:");
    scanf("%d",&t);
    for(int i=0;i<t;i++)
    {
          for( k=0;k<t-i;k++)
          {
              printf("*");
          }
        for( j=0;j<2*(t-k);j++)
        {
            printf(" ");
        }
        for( n=0;n<t-i;n++)
        {
            printf("*");
        }
        printf("\n");
      }
      for(i=t;i>=0;i--)
      {
          for(j=2*(t-k);j>0;j--)
          {
              printf(" ");
          }
          for(k=t-i;k>0;k--)
          {
              printf("*");
          }


          printf("\n");

      }

}

