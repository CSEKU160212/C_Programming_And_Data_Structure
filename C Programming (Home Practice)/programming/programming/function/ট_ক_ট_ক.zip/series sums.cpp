#include<stdio.h>
int main()

{
    long long int a,n,sum=0;
    int i;
    scanf("%lld %lld",&a,&n);
    for(i=a;i<=n;i=((i*10)+a))
    {

        {
            sum=sum+i;
        }
    }
    printf("sum is %lld.\n",sum);
}
