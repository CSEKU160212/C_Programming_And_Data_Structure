#include<stdio.h>
int main()
{
    int n,k,a,t,s;
    while(scanf("%d%d",&n,&k)==2)
    {
        a=n/k;
        t=a/k;
        s=n+a+t;
        printf("%d\n",s);
    }
}
