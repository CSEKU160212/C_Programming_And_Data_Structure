#include<stdio.h>
int main()

{
    int i,a,t,sum;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        scanf("%d",&a);
        if(a%3==0) sum=a+1;
        else if(a%3==1)
            sum=sum+1;
    }
    printf("%d",sum);
}
