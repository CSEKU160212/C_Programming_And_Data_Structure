#include<stdio.h>
int main()
{
    int i,n;
    long long sum=0;
    scanf("%d",&n);
    for(i=7;i<=n;i=(i*10)+7)
    {
        sum=sum+i;
    }
    printf("%lld\n",sum);
}
