#include<stdio.h>
int main()
{
    long long int i,n,sum=0;
    scanf("%lld",&n);
    for(i=1;i<=n;i++)
    {
        sum=(n*(n+1))/2;
    }
    printf("sum is %lld.\n",sum);
}
