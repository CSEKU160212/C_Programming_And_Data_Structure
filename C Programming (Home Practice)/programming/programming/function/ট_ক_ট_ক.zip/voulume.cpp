#include<stdio.h>
int main()
{
    int i,a,b,c,t,v;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        scanf("%d%d%d",&a,&b,&c);
        v=a*b*c;
        printf("%d\n",v);
    }
}













