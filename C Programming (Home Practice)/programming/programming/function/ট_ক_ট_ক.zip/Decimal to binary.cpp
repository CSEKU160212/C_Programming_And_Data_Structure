#include<stdio.h>
int main()
{
    int i,j;
    for(i=0;i<=10;i++)
    {
        for(j=1;j<=5;j++)

        {
            printf("%d\t",j);
        }
    }
    printf("%d\n",i);

}
