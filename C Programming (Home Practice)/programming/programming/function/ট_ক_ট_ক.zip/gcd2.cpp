#include<stdio.h>
int main()
{
    int a,b,i,rem;
    scanf("%d%d",&a,&b);
    for(i=1;;i++)
    {
        rem=a%b;
        if(rem==0)
        {
            break;
        }
         a=b;
         b=rem;
    }
    printf("gcd is %d.\n",b);
}
