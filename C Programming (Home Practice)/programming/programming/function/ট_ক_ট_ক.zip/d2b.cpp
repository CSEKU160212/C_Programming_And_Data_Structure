#include<stdio.h>
int main()
{
    int i,a,rem,count,res=0,bin=0;
    scanf("%d",&a);
    for(i=1;;i++)
    {
        rem=a%2;
        a=a/2;
        res=(res*10)+rem;
        count=i;
        if(a==0)
        {
            break;
        }

    }


    for(i=1;i<=count;i++)
    {
      rem=res%10;
      res=res/10;
      bin =(bin*10)+rem;

    }
    printf("binary is %d\n",bin);



}
