#include<stdio.h>
int main()
{
    int i,j,k,l,t;
    printf("enter a line to be printed:");
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        for(j=t-i;j>0;j--)
        {
          printf(" ");
        }
        for(k=i;k>0;k--)
        {
            printf("%d",k);
        }

        for(l=2;l<=i;l++)
        {
            printf("%d",l);
        }
        printf("\n");
    }
}
