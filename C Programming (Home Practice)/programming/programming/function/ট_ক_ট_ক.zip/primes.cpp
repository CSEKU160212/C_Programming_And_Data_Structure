#include<stdio.h>
#include<math.h>
int main()
{
    int a,b,i,root,flag=0;
    scanf("%d",&a);
    if(a==2) printf("%d is prime.\n",a);
    else if(a>2)
    {
        if(a%2==0)
        {
            printf("%d is not prime.\n",a);
        }
    }
    else
    {
        root=sqrt(a);
        for(i=3;i<=root;i=i+2)
        {

            if(a%i==0)
            {
                flag=1;
                printf("%d is not prime.\n",a);
                break;
            }

        }
        if(flag==0)
        {
            printf("%d is prime.\n",a);
        }

    }
}
