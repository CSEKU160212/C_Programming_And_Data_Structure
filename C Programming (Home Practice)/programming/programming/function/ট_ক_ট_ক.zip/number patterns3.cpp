#include<stdio.h>
int main()
{
    int i,j,k,l,t;
    printf("enter the line to be printed:");
    scanf("%d",&t);
    for(i=0;i<=t;i++)
    {
        for(j=1;j<=t-i;j++)
        {
            printf(" ");
        }
        for(k=1;k<=i;k++)
        {
            printf("*");
        }
        printf("\n");
    }

}
