                                //150232//

#include<stdio.h>
int main()
{
    int i,p;
    double b,prod;
    printf("b=\n");
    scanf("%lf",&b);
    printf("p=\n");
    scanf("%d",&p);
    prod=b;

    for(i=1;i<p;i++)
    {
        if(p>0)
        {
           prod=prod*(b);
        }
        else if(p<0)

        {
            for(i=1;i<1/p;i++)
            {
               prod=;
            }

        }
        else
        {
            prod=1;
        }

    }
      printf("%0.3lf\n",prod);

}
