                             //pattern:triangle//

#include<stdio.h>
int main()
{
    int i,j,k,t;
    printf("enter line to be printed:");
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        for(j=0;j<=t-i;j++)
        {
            printf(" ");
        }
        for(k=0;k<(2*i+1);k++)
        {
            printf("*");
        }
        printf("\n");

    }
}
