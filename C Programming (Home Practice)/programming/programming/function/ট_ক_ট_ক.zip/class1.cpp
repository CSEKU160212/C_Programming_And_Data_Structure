#include<stdio.h>
int main()
{
    int i,n,rem,sum=0;
    scanf("%d",&n);
    for(i=1; ;i++)
    {
        rem=n%10;
        sum=sum+rem;
        n=n/10;
        if(n==0)
        {
            printf("%d\n",rem);
            break;
        }
        if(n>0)
        printf("%d\n",rem);
    }

 printf("%Digit:%d\nsummation:%d\n",i,sum);

}
