#include<stdio.h>
int main()
{
    int i,j,c,d;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {

    }
}
