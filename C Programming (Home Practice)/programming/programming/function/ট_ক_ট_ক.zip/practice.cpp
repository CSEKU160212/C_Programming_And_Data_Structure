#include<stdio.h>
int main()
{
    int n=10;
    if(n>20)
    {
        printf("inside if.\n");
    }
    else if(n>0)
    {
        printf("inside else if.\n");
    }
}
