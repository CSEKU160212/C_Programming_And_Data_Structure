#include<stdio.h>
#include<math.h>
int main()
{
    double x1,y1,r,d,ans,a;
    int i,t;
    scanf("%d",&t);
    for(i=1;i<=t;i++)

    {
        scanf("%lf%lf%lf",&x1,&y1,&r);
        d=sqrt((x1*x1)+(y1*y1));
        a=d+r;
        if(d>r)ans=d-r;
        else ans=r-d;
        printf("%.2lf %.2lf\n",ans,a);
    }


}
