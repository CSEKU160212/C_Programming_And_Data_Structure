#include<stdio.h>
int main()
{
    int i,j,t;
    scanf("%d",&t);
    for(i=0; i<t; i++)
    {
        for(int k=1; k<=t-i; k++)
        {
            printf(" ");
        }
        for(j=1; j<=2*i-1; j++)
        {
            printf("*");
        }
        printf("\n");
    }
    for(i=t;i>=0;i--)
    {
        for(int k=t-i;k>0;k--)
        {
            printf(" ");
        }
        for(j=(2*i)-1;j>0;j--)
        {
            printf("*");
        }
        printf("\n");
    }
}
