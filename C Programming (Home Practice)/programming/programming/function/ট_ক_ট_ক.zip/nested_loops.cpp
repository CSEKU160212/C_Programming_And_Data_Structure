#include<stdio.h>
int main()
{
  int i,j,k,t;
  printf("enter the number")
}
