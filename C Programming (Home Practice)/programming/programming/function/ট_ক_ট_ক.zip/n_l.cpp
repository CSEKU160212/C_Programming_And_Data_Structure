#include<stdio.h>
int main()
{
    int i,j,k,t;
    printf("enter a num to be printed:");
    scanf("%d",&t);
    for(i=0; i<t; i++)
    {
        for(j=0; j<=t-i; j++)
        {
            printf(" ");
        }
        {
            for(k=t; k<=i-2; k--)
            {
                printf("*",k);
            }
            printf("\n");
        }
    }
}
