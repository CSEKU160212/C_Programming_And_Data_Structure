#include<stdio.h>
int main()
{
    int a,b,i,rem;
    scanf("%d %d",&a,&b);
    for(i=1;;i++)
    {
        rem=a%b;
        a=a/b;
        if(a==0)
        {
            break;
        }
    }
    printf("%d",rem);
}
