#include<stdio.h>
int main()
{
    int i,a,b,rem,s,x;
    scanf("%d %d",&a,&b);
    int m=a*b;
    for(i=1; ;i++)
    {
        rem=a%b;
        if(rem==0)
        {

            break;
        }
        a=b;
        b=rem;
    }
    s=b;
    x=m/s;
    printf("%d\n",x);




}

