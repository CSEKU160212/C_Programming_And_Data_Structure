#include<stdio.h>
int main()
{
    int t;
    printf("enter line to print:");
    scanf("%d",&t);
    for(int i=0;i<t;t++)
    {
        for(int j=t-i;j>=1;j--)
        {
            printf(" ");
        }
        for(int k=(2*i)+1;k>0;k--)
        {
            printf("#");
        }
        printf("\n");
    }
}
