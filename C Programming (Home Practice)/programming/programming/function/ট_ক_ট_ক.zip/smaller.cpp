#include<stdio.h>
int main()
{
    int i,t,a,b,smaller=0;
    scanf("%d",&t);
    scanf("%d %d",&a,&b);
    for(i=1;i<=t;i++)
    {

        if(a<b)
        {
            smaller=a;
        }
        else
        {
            smaller=b;
        }

    }
    printf("Case %d:smaller number is:%d",i,smaller);
}
