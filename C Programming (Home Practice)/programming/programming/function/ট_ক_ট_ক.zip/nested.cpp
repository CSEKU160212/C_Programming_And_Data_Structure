#include<stdio.h>
int main()
{
    int i,j,sum=0;
    for(i=1;i<10;i++)
    {
        for(j=0;j<5;i++)
        {
            sum=j;
        }
        printf("%d\n",sum);
    }
    printf("\n");
}
