#include<stdio.h>
#include<math.h>
int main()

{

    int i,n;
    double sum=0;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        sum+=(7*pow(10,i-1));
    }
    printf("Sum is %.0lf",sum);
}

