#include<stdio.h>
int main()

{
    int a,b,i;
   while()
    {
        i=a*b;printf("%d\n",i);

    }
    if(a==0|| b==0)

}
