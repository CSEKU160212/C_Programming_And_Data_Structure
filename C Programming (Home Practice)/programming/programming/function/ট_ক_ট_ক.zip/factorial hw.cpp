#include<stdio.h>
int main()

{
    int n,i,factorial=1;
    scanf("%d",&n);
    for(i=n;i>=n;i--)
    {
        if(n>0)
        {
          factorial=factorial*i;

        }
        else if(n<0)
        {
            printf("%d! is undefined.\n",n);
        }
        else
        {
            printf("1\n");
        }
    }
    printf("%d\n",factorial);
}

