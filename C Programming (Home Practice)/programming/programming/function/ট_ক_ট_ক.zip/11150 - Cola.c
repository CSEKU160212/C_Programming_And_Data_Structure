//*11150 - Cola//
#include<stdio.h>
int main()

{
    int n,sum;
    while(scanf("%d",&n)==1)
    {
        sum=n/2;
        sum=sum+n;
        printf("%d\n",sum);
    }
}
