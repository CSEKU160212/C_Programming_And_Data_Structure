#include<iostream>
using namespace std;
int main()
{
    int a;
    while(1)
    {
      cin>>a;
      if(a%6==0)cout<<"Y"<<endl;
      else cout<<"N"<<endl;
    }
}
