#include<stdio.h>
int main()
{
    int i,a,t;
    while(scanf("%d",&a)==1)
    {
        if(a==0)
        {
            break;
        }
        if(a%7==0)
        {
            a=a+77;
        }
        else if(a%11==0)
        {
            a=a+121;
        }
        else if(a%13==0)
        {
            a=a+169;
        }
        else
        {
            a=a;
        }
        printf("%d\t\n",a);
    }
}
