#include<stdio.h>
int main()
{
    int a=97;
    printf("%c\n",a);
}
