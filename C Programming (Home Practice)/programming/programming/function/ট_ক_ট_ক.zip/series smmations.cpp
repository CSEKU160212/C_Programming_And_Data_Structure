#include<stdio.h>
#include<math.h>
int main()
{
    double n,i,sum=0;

    for(i=7;i<=n;i=(10*i)+7)
    {
         scanf("%llf",&n);7

        sum=sum+i;

    }
    printf("%llf\n",sum);
}
