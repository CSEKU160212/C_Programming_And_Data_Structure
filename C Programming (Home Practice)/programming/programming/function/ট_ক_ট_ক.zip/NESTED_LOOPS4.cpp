#include<stdio.h>
int main()
{
    int i,j,k,l,t;
    printf("enrer a number to be printed:");
    scanf("%d",&t);
    printf("\n\n");
    for(i=0;i<t;i++)
    {
        for(j=1;j<=t-i;j++)
        {
            printf(" ");
        }
        for(k=1;k<=(2*i)+1;k++)
        {
            printf("%d",k);
        }
        printf("\n");

    }
}
