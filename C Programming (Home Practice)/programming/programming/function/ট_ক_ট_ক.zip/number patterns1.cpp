#include<stdio.h>
int main()
{
    int i,j,k,l,m,n,t;
    printf("enter line to be printed:");
    scanf("%d",&t);
    for(i=t; i>=0; i--)
    {
        {
            printf("*");
        }

        for(k=t;k>0;k--)
        {
            printf("*");
        }
        for(j=1;j<t-i;j++)
        {
            printf("  ");
        }
        for(l=t;l>0;l--)
        {
            printf("*");
        }
        printf("\n");


    }



}
