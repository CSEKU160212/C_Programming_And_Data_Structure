#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("in.txt", "r", stdin);
    //freopen("out.txt", "w", stdout);

    ///variables
    int i;
    int a, b;

    ///for each test case
    while( scanf("%d", &a) != EOF && a != 0 )
    {

        printf("%d *** %d\n",a, a*2);

    }

    return 0;
}
