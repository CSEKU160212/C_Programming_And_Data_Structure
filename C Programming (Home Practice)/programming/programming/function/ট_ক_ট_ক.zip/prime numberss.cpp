#include<stdio.h>
#include<math.h>
int main()
{
    int i,a,root,flag=0;
    scanf("%d",&a);
    if(a==1)printf("1 is not prime.\n");
    if(a%2==0)printf("2 is not prime.\n",a);
    for(i=1;;i++)
    {
        if(a>2)
        {
            if(a%2==0)printf("%d is not prime.\n",a);
        }
        else
        {
            root=sqrt(a);
            for(i=3;i<=root;i=i+2)
            {
                if(a%i==0)
                {
                    flag=1;
                    printf("%d is not prime.\n",a);
                }
            }
        }

    }
    if(flag==0)
                        {
                            printf("%d is prime.\n",a);
                        }

}
