#include<stdio.h>
int main()
{
    int i,t,a,b,c;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        scanf("%d%d%d",&a,&b,&c);
        if(a==20&&b==20&&c==20)
        {
            printf("Case :%d good\n",i);
        }
        else
        {
            printf("Case :%d bad",i);
        }
    }
}
