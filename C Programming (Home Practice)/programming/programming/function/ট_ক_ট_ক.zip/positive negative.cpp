#include<stdio.h>
int main()
{
    int i,a,b,t,count1=0,count2=0;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        scanf("%d",&a);
        if(a>0)
        {
          count1++;

        }
        if(a<0)
        {
            count2++;

        }
    }
    printf("%d %d\n",count1,count2);

}
